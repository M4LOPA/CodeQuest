package com.codequest

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

val Bg = Color(0xFF0A0A14)
val Panel = Color(0xFF14142B)
val Cyan = Color(0xFF00F0FF)
val Pink = Color(0xFFFF2E93)
val Green = Color(0xFF39FF88)

data class Question(val text: String, val options: List<String>, val answer: Int)
data class Planet(val name: String, val emoji: String, val color: Color, val questions: List<Question>)

val planets = listOf(
    Planet("Python", "🐍", Green, listOf(
        Question("Quel mot-clé définit une fonction ?", listOf("func", "def", "fn", "function"), 1),
        Question("Que renvoie len([1,2,3]) ?", listOf("2", "3", "4", "Erreur"), 1)
    )),
    Planet("Java", "☕", Pink, listOf(
        Question("Quel type stocke un entier ?", listOf("int", "string", "bool", "char"), 0),
        Question("Point d'entrée d'un programme Java ?", listOf("start()", "run()", "main()", "init()"), 2)
    )),
    Planet("JavaScript", "⚡", Color(0xFFFFE600), listOf(
        Question("Quel mot-clé déclare une constante ?", listOf("var", "let", "const", "def"), 2)
    )),
    Planet("SQL", "🗄️", Cyan, listOf(
        Question("Quelle commande lit des données ?", listOf("GET", "SELECT", "READ", "FETCH"), 1)
    )),
    Planet("Git", "🌿", Color(0xFFFF8A00), listOf(
        Question("Quelle commande enregistre un commit ?", listOf("git save", "git push", "git commit", "git add"), 2)
    ))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf("splash") }
    var xp by remember { mutableIntStateOf(0) }
    var streak by remember { mutableIntStateOf(1) }
    var current by remember { mutableStateOf(planets[0]) }

    when (screen) {
        "splash" -> {
            LaunchedEffect(Unit) { delay(1500); screen = "home" }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("CODE QUEST", color = Cyan, fontSize = 36.sp, fontWeight = FontWeight.Black)
                    Text("Deviens maître du code", color = Pink, fontSize = 14.sp)
                }
            }
        }
        "home" -> Home(xp, streak, onPlanet = { current = it; screen = "quiz" })
        "quiz" -> Quiz(current, onXp = { xp += it }, onDone = { streak = 1; screen = "home" })
    }
}

@Composable
fun Home(xp: Int, streak: Int, onPlanet: (Planet) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Niveau ${xp / 100 + 1}", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("🔥 $streak jour", color = Pink, fontSize = 18.sp)
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(progress = { (xp % 100) / 100f }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Cyan, trackColor = Panel)
        Text("$xp XP", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Text("Carte galactique", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(planets) { p ->
                Row(
                    Modifier.fillMaxWidth()
                        .border(1.dp, p.color, RoundedCornerShape(16.dp))
                        .background(Panel, RoundedCornerShape(16.dp))
                        .clickable { onPlanet(p) }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(p.emoji, fontSize = 32.sp)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(p.name, color = p.color, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("${p.questions.size} quête(s)", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun Quiz(planet: Planet, onXp: (Int) -> Unit, onDone: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    val q = planet.questions[index]

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("${planet.emoji} ${planet.name} — ${index + 1}/${planet.questions.size}", color = planet.color, fontSize = 18.sp)
        Spacer(Modifier.height(24.dp))
        Text(q.text, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        q.options.forEachIndexed { i, opt ->
            val border = when {
                picked == -1 -> Color.Gray
                i == q.answer -> Green
                i == picked -> Pink
                else -> Color.DarkGray
            }
            Text(
                opt, color = Color.White, fontSize = 18.sp,
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    .border(1.dp, border, RoundedCornerShape(12.dp))
                    .background(Panel, RoundedCornerShape(12.dp))
                    .clickable(enabled = picked == -1) {
                        picked = i
                        if (i == q.answer) onXp(25)
                    }
                    .padding(16.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        if (picked != -1) {
            Button(onClick = {
                if (index + 1 < planet.questions.size) { index++; picked = -1 } else onDone()
            }, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) {
                Text(if (index + 1 < planet.questions.size) "Suivant" else "Terminer")
            }
        }
    }
}
